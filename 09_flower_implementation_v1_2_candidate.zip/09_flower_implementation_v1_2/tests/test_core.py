import numpy as np
import torch
import pytest

from ndhs_flower.model import NDHSMLP, get_parameters, set_parameters
from ndhs_flower.training import train_local
from ndhs_flower.data_loader import load_partition
from ndhs_flower.reproducibility import flower_partition_to_region
from ndhs_flower.evaluation import _metrics

def test_parameter_roundtrip():
    source = NDHSMLP(15)
    target = NDHSMLP(15)
    set_parameters(target, get_parameters(source))
    assert all(torch.equal(a, b) for a, b in zip(source.state_dict().values(), target.state_dict().values()))

def test_mu_zero_repeatability():
    X = np.array([[.1,.2],[.2,.3],[.8,.7],[.9,.8]], dtype=np.float32)
    y = np.array([0,0,1,1], dtype=np.float32)
    initial = NDHSMLP(2).state_dict()
    models = []
    for _ in range(2):
        model = NDHSMLP(2)
        model.load_state_dict(initial)
        train_local(model, X, y, 1, 2, .001, 0.0, 777)
        models.append(model)
    assert all(torch.equal(a, b) for a, b in zip(models[0].state_dict().values(), models[1].state_dict().values()))

def test_partition_mapping():
    assert [flower_partition_to_region(i, 6) for i in range(6)] == [1,2,3,4,5,6]
    with pytest.raises(ValueError):
        flower_partition_to_region(6, 6)
    with pytest.raises(ValueError):
        flower_partition_to_region(0, 5)

def test_partition_loader_rejects_duplicate_ids(tmp_path):
    path = tmp_path / "duplicate.npz"
    np.savez(path, X=np.ones((2,2),np.float32), y=np.array([0,1],np.float32),
             source_row_id=np.array(["x","x"],object), v024=np.array([1,1]))
    with pytest.raises(ValueError, match="Duplicate"):
        load_partition(path, 1)

def test_region_isolation(tmp_path):
    path = tmp_path / "toy.npz"
    np.savez(path, X=np.ones((6,2),np.float32), y=np.array([0,1,0,1,0,1],np.float32),
             source_row_id=np.array(["a","b","c","d","e","f"],object), v024=np.array([1,1,2,2,3,3]))
    X, y, ids = load_partition(path, 2)
    assert len(X) == 2 and set(ids) == {"c","d"}

def test_metrics_and_one_class_status():
    metrics = _metrics(np.array([0,0,1,1]), np.array([.1,.4,.6,.9]))
    assert metrics["tn"] + metrics["fp"] + metrics["fn"] + metrics["tp"] == 4
    assert 0 <= metrics["ece_10"] <= 1
    one_class = _metrics(np.array([0,0]), np.array([.1,.2]))
    assert np.isnan(one_class["auroc"])
    assert one_class["calibration_status"] == "undefined_one_class"
